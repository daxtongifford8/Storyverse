# STORYVERSE prototype

Open `index.html` in a modern browser to try the interactive prototype.

## What works
- Choose from six story themes
- Create a room and add player/character names
- Mixed, group, and individual turn-style settings
- Free-text actions (not just multiple choice)
- Shared timeline display and scene progression

## Important limitation
This is a front-end prototype. It stores state only in the current browser session and does not synchronize between devices. A true online multiplayer version needs:
- a hosted backend/database for rooms, players, actions, and story state
- real-time updates (for example WebSockets or a realtime database)
- an AI storyteller service on a secure server
- user authentication or secure room invite links

Do not put private API keys in the browser. Deploy the front end to a static host and connect it to a backend before inviting friends to a live shared game.
